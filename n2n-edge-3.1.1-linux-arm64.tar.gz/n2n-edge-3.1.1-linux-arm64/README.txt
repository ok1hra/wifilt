n2n edge 3.1.1 for Linux arm64 -- the client of WIFILT's remote access, for a
computer without WIFILT (a laptop). With WIFILT installed you do not need this:
its archive carries the same edge and SETUP -> Remote access runs it.

Install:
  sudo install -m 0755 edge /usr/local/sbin/edge

Join the VPN of your station -- the community and the key are in the station's
SETUP -> Remote access -> Advanced (after SHOW):
  sudo N2N_KEY=<key> /usr/local/sbin/edge -d wlvpn0 -c <community> -l remoteqth.com:82 -A4 -I LAPTOP -f

The station is then at its VPN address, http://10.x.y.z/ -- SETUP lists it.
Manual: https://github.com/ok1hra/wifilt/blob/main/SOFTWARE.md#19-remote-access-over-the-internet-pc-and-raspberry-pi
Source and licence: SOURCE.txt, LICENSE (GPL-3.0).
