#!/usr/bin/env bash
#
# Install WIFILT on Linux.
#
#   sudo ./install.sh              install to /opt/wifilt
#   sudo ./install.sh --prefix DIR install somewhere else
#   sudo ./install.sh --uninstall
#
# What it does and why:
#
#   * copies the binary and the data/ tree to $PREFIX
#   * grants CAP_NET_BIND_SERVICE, without which ports 80, 82 and 83 cannot be
#     bound -- the binary then moves them to 8080/8082/8083, which works but
#     changes the browser's origin and with it which QSO log the page shows
#   * installs a systemd unit that is NOT enabled by default -- two, when
#     local-trx is bundled next to this script
#
# It deliberately does not touch the configuration directory. That lives in the
# user's ~/.config/wifilt and holds callsign, radio credentials and the TX-gain
# calibration; reinstalling must never disturb it, exactly as a firmware flash
# on the hardware box must not wipe the config partition.

set -euo pipefail

PREFIX="/opt/wifilt"
UNINSTALL=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --prefix)    PREFIX="$2"; shift 2 ;;
    --uninstall) UNINSTALL=1; shift ;;
    -h|--help)   sed -n '2,22p' "$0" | sed 's/^# \?//'; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 1 ;;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "needs root -- the capability and the unit file both do" >&2
  exit 1
fi

UNIT=/etc/systemd/system/wifilt.service
LOCAL_TRX_UNIT=/etc/systemd/system/local-trx.service
UPD_UNITS=(wifilt-update.path wifilt-update.service wifilt-update-check.timer wifilt-update-check.service)
UPD_STATE=/var/lib/wifilt-update
UPD_CONF=/etc/wifilt-update.conf

if [[ $UNINSTALL -eq 1 ]]; then
  systemctl disable --now wifilt local-trx wifilt-update.path wifilt-update-check.timer 2>/dev/null || true
  rm -f "$UNIT" "$LOCAL_TRX_UNIT" "$UPD_CONF"
  for u in "${UPD_UNITS[@]}"; do rm -f "/etc/systemd/system/$u"; done
  rm -rf "$UPD_STATE" "$PREFIX.prev"
  systemctl daemon-reload 2>/dev/null || true
  rm -rf "$PREFIX"
  echo "removed $PREFIX and the service."
  echo "your configuration in ~/.config/wifilt was left alone."
  exit 0
fi

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BINARY="$HERE/wifilt"
ASSETS="$HERE/data"
[[ -x "$BINARY" ]] || { echo "wifilt not found next to this script" >&2; exit 1; }
[[ -d "$ASSETS" ]] || { echo "data/ not found next to this script" >&2; exit 1; }

install -d "$PREFIX"
install -m 0755 "$BINARY" "$PREFIX/wifilt"
rm -rf "$PREFIX/data"
cp -r "$ASSETS" "$PREFIX/data"

# start-wifilt.sh (native/Makefile's dist-linux/dist-arm64 targets, next to
# this script) -- the shared launcher that starts wifilt (and local-trx, if
# also installed below) and opens both web interfaces, for an operator who
# would otherwise have no way to know there even are two separate programs.
[[ -f "$HERE/start-wifilt.sh" ]] && install -m 0755 "$HERE/start-wifilt.sh" "$PREFIX/start-wifilt.sh"

# The release (firmware REV) this came from -- pi-setup and fslock show it.
[[ -f "$HERE/VERSION" ]] && install -m 0644 "$HERE/VERSION" "$PREFIX/VERSION"

# The web updater (native/update/, SOFTWARE.md "Updating from the web") and the
# channel it reads. Its units are written further down.
HAVE_UPDATER=0
if [[ -f "$HERE/wifilt-update.sh" ]]; then
  install -m 0755 "$HERE/wifilt-update.sh" "$PREFIX/wifilt-update"
  [[ -f "$HERE/update-channel.conf" ]] && install -m 0644 "$HERE/update-channel.conf" "$PREFIX/update-channel.conf"
  HAVE_UPDATER=1
fi

# The one privileged step. It is a property of the file, so it has to be redone
# after every upgrade -- which is why upgrading means re-running this script.
setcap cap_net_bind_service=+ep "$PREFIX/wifilt"

# local-trx (docs/local-trx-implementace.md) is optional and bundled into the
# release archive by tools/release.sh's own separate step, sitting right next
# to $BINARY -- but until now nothing here ever looked for it, so it was
# silently left behind in the extracted archive instead of reaching $PREFIX
# (found live: `sudo ./install.sh` then `/opt/wifilt/wifilt` produced no
# local-trx to run at all). Copy it across the same way, but do not start,
# enable or auto-open anything -- local-trx's own config.json "enabled"
# switch already defaults to off (bod: master switch) until an operator has
# walked through its setup wizard, the same caution wifilt.service's own
# "installed but not enabled" gets below.
LOCAL_TRX_BIN="$HERE/local-trx"
LOCAL_TRX_WEBUI="$HERE/webui"
if [[ -x "$LOCAL_TRX_BIN" && -d "$LOCAL_TRX_WEBUI" ]]; then
  install -m 0755 "$LOCAL_TRX_BIN" "$PREFIX/local-trx"
  rm -rf "$PREFIX/webui"
  cp -r "$LOCAL_TRX_WEBUI" "$PREFIX/webui"
  INSTALLED_LOCAL_TRX=1
else
  INSTALLED_LOCAL_TRX=0
fi

# Runs as the invoking user, not root: the config lives in their home directory,
# and nothing here needs root once the capability is granted.
RUN_USER="${SUDO_USER:-$USER}"
cat > "$UNIT" <<EOF
[Unit]
Description=WIFILT - web interface for networked transceivers
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$RUN_USER
ExecStart=$PREFIX/wifilt --data-dir $PREFIX/data
Restart=on-failure
RestartSec=5
# stdin is not a terminal under systemd; the binary handles that (its serial
# console latches EOF instead of spinning), but there is nothing to read either.
StandardInput=null

[Install]
WantedBy=multi-user.target
EOF

# The headless case (a Raspberry Pi with no desktop, browser on a phone or
# laptop over WiFi) has no launcher to run and no terminal to keep open, so
# local-trx gets its own unit -- installed, like wifilt's, but not enabled.
# Same user as wifilt.service: local-trx's config.json lives in that user's
# ~/.config too. Nothing in it opens hardware before the wizard has turned
# "enabled" on; until then it serves only the wizard on :8765, reachable
# from the network (INADDR_ANY) despite the 127.0.0.1 its log line prints.
# The wizard's Save re-execs the process in place (same PID), which systemd
# sees as the service still running, not as a restart.
if [[ $INSTALLED_LOCAL_TRX -eq 1 ]]; then
  cat > "$LOCAL_TRX_UNIT" <<EOF
[Unit]
Description=local-trx - ICOM LAN bridge for a hamlib/soundcard transceiver
After=network-online.target sound.target
Wants=network-online.target

[Service]
Type=simple
User=$RUN_USER
# Soundcard and serial CAT/DTR/RTS, even when the user is not in these
# groups -- on a desktop the session grants them, under systemd nothing does.
SupplementaryGroups=audio dialout
# No display to open the wizard on; same switch start-wifilt.sh uses.
Environment=LOCAL_TRX_SKIP_AUTO_OPEN=1
ExecStart=$PREFIX/local-trx
Restart=on-failure
RestartSec=5
StandardInput=null

[Install]
WantedBy=multi-user.target
EOF
else
  # An archive without local-trx must not leave a unit pointing at a binary
  # an earlier install put there.
  systemctl disable --now local-trx 2>/dev/null || true
  rm -f "$LOCAL_TRX_UNIT"
fi

# The web updater. wifilt runs as $RUN_USER and cannot install anything; it
# drops req/request.json into a directory it owns, the path unit sees it and
# starts wifilt-update as root. The script takes only an action name from the
# request -- never a URL, a version or a path -- so the most a web user can ask
# for is "the newest official build of this edition, SHA256-checked".
# Enabled on purpose, unlike wifilt.service: both units are passive (a path
# watch and a 12-hour check), neither touches the radio.
if [[ $HAVE_UPDATER -eq 1 ]]; then
  install -d -m 0755 "$UPD_STATE"
  install -d -m 0755 -o "$RUN_USER" "$UPD_STATE/req"
  printf 'PREFIX=%q\nRUN_USER=%q\n' "$PREFIX" "$RUN_USER" > "$UPD_CONF"
  chmod 0644 "$UPD_CONF"
  cat > /etc/systemd/system/wifilt-update.path <<EOF
[Unit]
Description=WIFILT web updater - request watch

[Path]
PathExists=$UPD_STATE/req/request.json
Unit=wifilt-update.service

[Install]
WantedBy=multi-user.target
EOF
  cat > /etc/systemd/system/wifilt-update.service <<EOF
[Unit]
Description=WIFILT web updater
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$PREFIX/wifilt-update --from-request
# Must outlive the wifilt.service it stops and restarts.
KillMode=process
TimeoutStartSec=30min
EOF
  cat > /etc/systemd/system/wifilt-update-check.service <<EOF
[Unit]
Description=WIFILT web updater - look for a new build
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$PREFIX/wifilt-update check
EOF
  cat > /etc/systemd/system/wifilt-update-check.timer <<EOF
[Unit]
Description=WIFILT web updater - look for a new build twice a day

[Timer]
OnBootSec=3min
OnUnitActiveSec=12h
RandomizedDelaySec=15min

[Install]
WantedBy=timers.target
EOF
fi

systemctl daemon-reload
if [[ $HAVE_UPDATER -eq 1 ]]; then
  systemctl enable --now wifilt-update.path wifilt-update-check.timer >/dev/null 2>&1 \
    || echo "WARNING: could not enable the web updater units" >&2
fi

# start-wifilt.sh (copied above, if this archive has it) starts wifilt AND
# local-trx (if also installed) and opens both web interfaces -- the
# recommended manual alternative to systemd once both are actually wanted
# running. Falls back to naming the raw binary for an older extracted
# archive that predates the launcher.
if [[ -f "$PREFIX/start-wifilt.sh" ]]; then
  RUN_LINE="  or just run it     $PREFIX/start-wifilt.sh  (opens the browser itself)"
else
  RUN_LINE="  or just run it     $PREFIX/wifilt"
fi

cat <<EOF

installed to $PREFIX

  start now          sudo systemctl start wifilt
  start at boot      sudo systemctl enable --now wifilt
$RUN_LINE

then open            http://wifilt.local

The service is installed but NOT enabled -- starting a transmitter's control
interface at boot should be a decision, not a side effect of installing.
EOF

if [[ $INSTALLED_LOCAL_TRX -eq 1 ]]; then
  cat <<EOF

local-trx (PC bridge for a non-Icom radio, see BUILD.md § 5) was also found
next to this script and installed to $PREFIX/local-trx.

  start both now     sudo systemctl start wifilt local-trx
  start at boot      sudo systemctl enable --now wifilt local-trx

then open            http://<this machine's IP>:8765  (local-trx wizard)

It stays disabled until its setup wizard is used once to turn it on; in
wifilt's SETUP the ICOM-LAN address is then 127.0.0.1. Without systemd,
$PREFIX/start-wifilt.sh above starts it alongside wifilt and opens both
wizards' pages; running $PREFIX/local-trx directly works too.
EOF
fi
